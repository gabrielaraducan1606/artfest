import React from "react";

export default function ComenzileMele() {
  return (
    <div style={{ padding: "1rem" }}>
      <h2>Comenzile mele</h2>
      <p>Aici vei putea vizualiza și administra comenzile primite.</p>
    </div>
  );
}
