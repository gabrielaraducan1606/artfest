import styles from "./TabForms.module.css";

export function ParentsForm() {
  return (
    <div className={styles.form}>
      <h2>Părinți</h2>
      <p>Adaugă informații despre părinți aici.</p>
    </div>
  );
}
