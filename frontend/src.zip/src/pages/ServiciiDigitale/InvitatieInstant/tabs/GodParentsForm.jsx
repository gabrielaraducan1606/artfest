import styles from "./TabForms.module.css";

export function GodparentsForm() {
  return (
    <div className={styles.form}>
      <h2>Nași</h2>
      <p>Adaugă informații despre nași aici.</p>
    </div>
  );
}
