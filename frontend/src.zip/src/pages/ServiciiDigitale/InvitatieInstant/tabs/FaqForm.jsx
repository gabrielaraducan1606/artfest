import styles from "./TabForms.module.css";

export function FAQForm() {
  return (
    <div className={styles.form}>
      <h2>FAQ</h2>
      <p>Adaugă întrebări și răspunsuri pentru invitați.</p>
    </div>
  );
}
